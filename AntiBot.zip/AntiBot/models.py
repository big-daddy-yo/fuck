from django.db import models

class GoogleCrawler(models.Model):
    ip = models.CharField(max_length=100, primary_key=True)

class user_account(models.Model):
    api_key = models.CharField(max_length=200, primary_key=True)
    status = models.CharField(max_length=200)
    time = models.IntegerField(null=False, default=0, blank=False)

