from django.shortcuts import render
from django.http import JsonResponse
from AntiBot.scripts.crawler_check import google
from revproxy.views import ProxyView
from revproxy.views import DiazoProxyView

def index(request):
    """View function for home page of site."""

    if request.method == 'POST':
        print(request.POST)
        data = {"dns":google(request.POST["ipinfo"])}

        return JsonResponse(data)

    else:
        return False

def TestProxyView(DiazoProxyView):
    upstream = 'https://www.google.com'
    bz = DiazoProxyView(upstream='http://example.com/',
                        html5=True,
                        diazo_theme_template='base.html',
                        )
    return bz