import os
import subprocess
import json

def google(ipadd):
    output = str(subprocess.check_output("host %s" % ipadd, shell=True))
    if "google" in output:
        return False

    else:
        return True

def amazon(ipadd):
    output = str(subprocess.check_output("host %s" % ipadd, shell=True))
    if "google" in output:
        return False

    else:
        return True

def google(ipadd):
    output = str(subprocess.check_output("host %s" % ipadd, shell=True))
    if "google" in output:
        return False

    else:
        return True